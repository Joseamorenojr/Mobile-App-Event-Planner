package com.example.eventtracker;

import android.content.Intent;
import android.database.Cursor;
import android.os.Bundle;
import android.widget.Button;
import android.widget.GridView;
import android.widget.SimpleCursorAdapter;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

public class MainActivity extends AppCompatActivity {

    GridView gridView;
    Button btnAddEvent;
    DatabaseHelper db;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        db = new DatabaseHelper(this);
        gridView = findViewById(R.id.gridEvents);
        btnAddEvent = findViewById(R.id.btnAddEvent);

        loadEvents();

        gridView.setOnItemClickListener((parent, view, position, id) -> {
            // Open the event detail screen instead of deleting
            Intent intent = new Intent(MainActivity.this, EventDetailActivity.class);
            intent.putExtra("EVENT_ID", (int) id); // pass event ID
            startActivity(intent);
        });

        btnAddEvent.setOnClickListener(v ->
                startActivity(new Intent(this, AddEventActivity.class)));
    }

    private void loadEvents() {
        Cursor c = db.getAllEvents(); // cursor contains _id
        String[] from = new String[]{"title", "date", "time"}; // map columns to views
        int[] to = new int[]{R.id.tvTitle, R.id.tvDate, R.id.tvTime};
        SimpleCursorAdapter adapter = new SimpleCursorAdapter(
                this,
                R.layout.event_item,
                c,
                from,
                to,
                0
        );
        gridView.setAdapter(adapter);
    }
}