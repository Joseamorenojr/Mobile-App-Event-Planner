package com.example.eventtracker;

import android.content.Intent;
import android.database.Cursor;
import android.os.Bundle;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

public class EventDetailActivity extends AppCompatActivity {

    TextView tvTitle, tvDate, tvTime;
    Button btnEdit, btnDelete;
    DatabaseHelper db;
    int eventId;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.detail_event_item); // NEW layout

        db = new DatabaseHelper(this);

        tvTitle = findViewById(R.id.tvDetailTitle);
        tvDate = findViewById(R.id.tvDetailDate);
        tvTime = findViewById(R.id.tvDetailTime);

        btnEdit = findViewById(R.id.btnEdit);
        btnDelete = findViewById(R.id.btnDelete);

        // Get event ID passed from MainActivity
        eventId = getIntent().getIntExtra("EVENT_ID", -1);

        loadEvent(eventId);

        // Delete the event
        btnDelete.setOnClickListener(v -> {
            db.deleteEvent(eventId);
            Toast.makeText(this, "Event deleted", Toast.LENGTH_SHORT).show();
            finish(); // go back to main screen
        });

        // Edit the event → opens AddEventActivity with event data
        btnEdit.setOnClickListener(v -> {
            Intent intent = new Intent(EventDetailActivity.this, AddEventActivity.class);
            intent.putExtra("EVENT_ID", eventId);
            startActivity(intent);
        });
    }

    private void loadEvent(int id) {
        Cursor c = db.getEvent(id); // Make sure this exists
        if (c != null && c.moveToFirst()) {
            tvTitle.setText(c.getString(c.getColumnIndexOrThrow("title")));
            tvDate.setText(c.getString(c.getColumnIndexOrThrow("date")));
            tvTime.setText(c.getString(c.getColumnIndexOrThrow("time")));
            c.close();
        }
    }
}