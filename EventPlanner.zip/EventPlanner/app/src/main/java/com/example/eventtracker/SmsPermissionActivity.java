package com.example.eventtracker;

import android.Manifest;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.os.Bundle;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;

public class SmsPermissionActivity extends AppCompatActivity {

    private static final int SMS_PERMISSION_CODE = 1001;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_sms_permission);

        TextView permissionText = findViewById(R.id.text_sms_permission);
        Button requestButton = findViewById(R.id.btn_request_sms_permission);
        Button skipButton = findViewById(R.id.btn_skip_sms_permission);

        // Request SMS permission
        requestButton.setOnClickListener(v -> checkAndRequestPermission());

        // Skip / Exit SMS permission
        skipButton.setOnClickListener(v -> {
            Toast.makeText(this, "Skipped SMS permission", Toast.LENGTH_SHORT).show();
            startActivity(new Intent(this, MainActivity.class));
            finish(); // finish this activity so back button won't return here
        });
    }

    private void checkAndRequestPermission() {
        if (ContextCompat.checkSelfPermission(this, Manifest.permission.SEND_SMS)
                == PackageManager.PERMISSION_GRANTED) {
            Toast.makeText(this, "SMS Permission already granted!", Toast.LENGTH_SHORT).show();
            // Proceed to main activity
            startActivity(new Intent(this, MainActivity.class));
            finish();
        } else {
            ActivityCompat.requestPermissions(
                    this,
                    new String[]{Manifest.permission.SEND_SMS},
                    SMS_PERMISSION_CODE
            );
        }
    }

    @Override
    public void onRequestPermissionsResult(int requestCode,
                                           @NonNull String[] permissions,
                                           @NonNull int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);

        if (requestCode == SMS_PERMISSION_CODE) {
            if (grantResults.length > 0 && grantResults[0] == PackageManager.PERMISSION_GRANTED) {
                Toast.makeText(this, "SMS Permission granted!", Toast.LENGTH_SHORT).show();
            } else {
                Toast.makeText(this, "SMS Permission denied!", Toast.LENGTH_SHORT).show();
            }
            // Go to main activity either way
            startActivity(new Intent(this, MainActivity.class));
            finish();
        }
    }
}