package com.example.eventtracker;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

public class DatabaseHelper extends SQLiteOpenHelper {
    private static final String DB_NAME = "eventtracker.db";
    private static final int DB_VERSION = 2; // bump version so onUpgrade runs

    // User table
    private static final String TABLE_USERS = "users";
    private static final String COL_USER_ID = "id";
    private static final String COL_USERNAME = "username";
    private static final String COL_PASSWORD = "password";

    // Event table
    private static final String TABLE_EVENTS = "events";
    private static final String COL_EVENT_ID = "_id"; // must be _id for CursorAdapter
    private static final String COL_EVENT_TITLE = "title";
    private static final String COL_EVENT_DATE = "date";
    private static final String COL_EVENT_TIME = "time";
    private static final String COL_EVENT_DESCRIPTION = "description";

    public DatabaseHelper(Context context) {
        super(context, DB_NAME, null, DB_VERSION);
    }

    @Override
    public void onCreate(SQLiteDatabase db) {
        // Create Users table
        String createUsers = "CREATE TABLE " + TABLE_USERS + " (" +
                COL_USER_ID + " INTEGER PRIMARY KEY AUTOINCREMENT, " +
                COL_USERNAME + " TEXT UNIQUE, " +
                COL_PASSWORD + " TEXT)";
        db.execSQL(createUsers);

        // Create Events table
        String createEvents = "CREATE TABLE " + TABLE_EVENTS + " (" +
                COL_EVENT_ID + " INTEGER PRIMARY KEY AUTOINCREMENT, " +
                COL_EVENT_TITLE + " TEXT, " +
                COL_EVENT_DATE + " TEXT, " +
                COL_EVENT_TIME + " TEXT, " +
                COL_EVENT_DESCRIPTION + " TEXT)";
        db.execSQL(createEvents);
    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldV, int newV) {
        db.execSQL("DROP TABLE IF EXISTS " + TABLE_USERS);
        db.execSQL("DROP TABLE IF EXISTS " + TABLE_EVENTS);
        onCreate(db);
    }

    // User methods
    public boolean registerUser(String username, String password) {
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues cv = new ContentValues();
        cv.put(COL_USERNAME, username);
        cv.put(COL_PASSWORD, password);
        long result = db.insert(TABLE_USERS, null, cv);
        return result != -1;
    }

    public boolean checkUser(String username, String password) {
        SQLiteDatabase db = this.getReadableDatabase();
        Cursor c = db.rawQuery("SELECT * FROM " + TABLE_USERS +
                " WHERE username=? AND password=?", new String[]{username, password});
        boolean exists = c.getCount() > 0;
        c.close();
        return exists;
    }

    // Event methods
    public long addEvent(String title, String date, String time, String description) {
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues cv = new ContentValues();
        cv.put(COL_EVENT_TITLE, title);
        cv.put(COL_EVENT_DATE, date);
        cv.put(COL_EVENT_TIME, time);
        cv.put(COL_EVENT_DESCRIPTION, description);
        return db.insert(TABLE_EVENTS, null, cv);
    }

    public Cursor getAllEvents() {
        SQLiteDatabase db = this.getReadableDatabase();
        // Select _id column for CursorAdapter compatibility
        return db.rawQuery("SELECT _id, title, date, time, description FROM " + TABLE_EVENTS, null);
    }

    public Cursor getEvent(int id) {
        SQLiteDatabase db = this.getReadableDatabase();
        return db.query("events", null, "_id=?", new String[]{String.valueOf(id)}, null, null, null);
    }

    public long deleteEvent(int id) {
        SQLiteDatabase db = this.getWritableDatabase();
        db.delete(TABLE_EVENTS, "_id=?", new String[]{String.valueOf(id)});
        return 0;
    }
}