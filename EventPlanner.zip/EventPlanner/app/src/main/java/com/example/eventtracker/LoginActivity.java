package com.example.eventtracker;

import android.content.Intent;
import android.os.Bundle;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

public class LoginActivity extends AppCompatActivity {
    EditText etUsername, etPassword;
    Button btnLogin, btnRegister, btnContinueWithoutLogin;
    DatabaseHelper db;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login);

        db = new DatabaseHelper(this);
        etUsername = findViewById(R.id.etUsername);
        etPassword = findViewById(R.id.etPassword);
        btnLogin = findViewById(R.id.btnLogin);
        btnRegister = findViewById(R.id.btnRegister);
        btnContinueWithoutLogin = findViewById(R.id.btnContinueWithoutLogin);

        // Login
        btnLogin.setOnClickListener(v -> {
            String user = etUsername.getText().toString();
            String pass = etPassword.getText().toString();
            if (db.checkUser(user, pass)) {
                Toast.makeText(this, "Login success", Toast.LENGTH_SHORT).show();
                // Go to SMS permission after login
                startActivity(new Intent(this, SmsPermissionActivity.class));
                finish(); // prevent back to login
            } else {
                Toast.makeText(this, "Invalid credentials", Toast.LENGTH_SHORT).show();
            }
        });

        // Register
        btnRegister.setOnClickListener(v -> {
            String user = etUsername.getText().toString();
            String pass = etPassword.getText().toString();
            if (db.registerUser(user, pass)) {
                Toast.makeText(this, "Registered successfully!", Toast.LENGTH_SHORT).show();
            } else {
                Toast.makeText(this, "Registration failed", Toast.LENGTH_SHORT).show();
            }
        });

        // Continue without login → skip SMS permission
        btnContinueWithoutLogin.setOnClickListener(v -> {
            startActivity(new Intent(this, MainActivity.class));
            finish(); // prevent back to login
        });
    }
}